package com.example.listalumnos

data class Alumno(val nombre: String, val cuenta: String, val correo: String, val imagen: String)